// Importaciones necesarias
const { Router } = require('express');
const bcrypt = require('bcrypt');
const faker = require('faker'); // Asegúrate de tener instalado faker
const User = require('../models/User'); // Modelo de usuarios (ajusta según tu estructura)
const Pet = require('../models/Pet'); // Modelo de mascotas (ajusta según tu estructura)

// Inicializar el router
const router = Router();

// Módulo para generar usuarios mockeados
const generateMockUsers = (count) => {
    const users = [];
    const passwordHash = bcrypt.hashSync('coder123', 10);

    for (let i = 0; i < count; i++) {
        users.push({
            name: faker.name.findName(),
            email: faker.internet.email(),
            password: passwordHash,
            role: faker.random.arrayElement(['user', 'admin']),
            pets: []
        });
    }
    return users;
};

// Endpoint para mockear mascotas (previo desafío entregable)
router.get('/mockingpets', (req, res) => {
    const pets = Array.from({ length: 10 }, () => ({
        name: faker.name.firstName(),
        type: faker.random.arrayElement(['dog', 'cat', 'bird']),
        age: faker.datatype.number({ min: 1, max: 15 })
    }));

    res.json({ success: true, pets });
});

// Endpoint para generar usuarios mockeados
router.get('/mockingusers', (req, res) => {
    const users = generateMockUsers(50);
    res.json({ success: true, users });
});

// Endpoint para generar datos y guardarlos en la base de datos
router.post('/generateData', async (req, res) => {
    const { users: userCount, pets: petCount } = req.body;

    if (!userCount || !petCount) {
        return res.status(400).json({ success: false, message: 'Parámetros inválidos' });
    }

    try {
        // Generar usuarios
        const users = generateMockUsers(userCount);
        const createdUsers = await User.insertMany(users);

        // Generar mascotas
        const pets = Array.from({ length: petCount }, () => ({
            name: faker.name.firstName(),
            type: faker.random.arrayElement(['dog', 'cat', 'bird']),
            age: faker.datatype.number({ min: 1, max: 15 })
        }));
        const createdPets = await Pet.insertMany(pets);

        res.json({
            success: true,
            message: 'Datos generados e insertados con éxito',
            createdUsers: createdUsers.length,
            createdPets: createdPets.length
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error al generar datos' });
    }
});

module.exports = router;
